# Ansible Collection - my_own_namespace.yandex_cloud_elk

This collection contains:
1) the module which creates the text file with a specified content;
2) the role which supposes to use the module.

